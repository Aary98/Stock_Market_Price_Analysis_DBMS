select * from bhartiartl;
select * from maruti;

select * from ultracemco;

alter table maruti
add column new_date date;
UPDATE maruti
SET	new_date=str_to_date(Date,'%d-%m-%Y');
alter table bhartiartl
add column new_date date;
UPDATE bhartiartl
SET	new_date=str_to_date(Date,'%d-%m-%Y');
alter table ultracemco
add column new_date date;
UPDATE ultracemco
SET	new_date=str_to_date(Date,'%d-%m-%Y');
/*Q1-----FIND VOLITALITY-----*/
drop view A1;
create view A1 as (select symbol,high,low from bhartiartl

union
select symbol,high,low from maruti

union

select symbol,high,low from ultracemco);
select * from A1;

select symbol,round(avg(high-low),2) as avg_volatility,dense_rank()
over(order by avg(high-low)asc)as ranking from A1
group by symbol;
/*Q2-----FIND DROPDOWN-----*/
/*-----FOR maruti-----*/
set @pre_covid_price_maruti := (select close from maruti
where Date="20-02-2020");
set @post_covid_price_maruti := (select close from maruti
where Date="23-03-2020");

select @post_covid_price_maruti;
select @pre_covid_price_maruti;

/*DROPDOWN FOR MARUTI*/

select round(((-@pre_covid_price_maruti
+@post_covid_price_maruti)/@pre_covid_price_maruti),5)*100 AS maruti_down;



/*-----FOR bhartiartl-----*/
set @pre_covid_price_bhartiartl:= (select close from bhartiartl
where Date="20-02-2020");
set @post_covid_price_bhartiartl:= (select close from bhartiartl
where Date="23-03-2020");

select @post_covid_price_bhartiartl;
select @pre_covid_price_bhartiartl;

/*DROPDOWN FOR bhartiartl*/

select round(((-@pre_covid_price_bhartiartl+@post_covid_price_bhartiartl)/@pre_covid_price_bhartiartl),5)*100 AS bhartiartl_down;



/*-----FOR ultracemco-----*/
set @pre_covid_price_ultracemco:= (select close from ultracemco
where Date="20-02-2020");
set @post_covid_price_ultracemco:= (select close from ultracemco
where Date="23-03-2020");

select @post_covid_price_ultracemco;
select @pre_covid_price_ultracemco;

/*DROPDOWN FOR ultracemco*/

select round(((-@pre_covid_price_ultracemco+@post_covid_price_ultracemco)/@pre_covid_price_ultracemco),5)*100 AS ultracemco_down;
/*
ultratech cement fall -31.012%
Bharti Artel fall -25.34%
maruti suzuki fall -37.55%*/

create table covid_downfall_per
(symbol varchar(100),percentage_fall double);
insert into covid_downfall_per
(symbol,percentage_fall)
values("MARUTI",-37.55),("BHARATIART",-25.34),("ULTRACEMCO",-31.01);

select *,dense_rank() over(order by percentage_fall desc)as ranking from covid_downfall_per;


/* NUMBER OF DAYES STOCK PRICE TOOK TO REACH ITS PRE COVID LEVELS*/
/*--Maruti SUZUKI__*/

set @date_close_more_than_precovid_maruti:=(select new_date from(select new_date,close,row_number() over(order by new_date asc)
as rank_based_on_new_date from maruti where new_date between "2020-03-23" and "2021-04-30" and close>= @pre_covid_price_maruti)
as A3 where rank_based_on_new_date =1);
select @date_close_more_than_precovid_maruti;
select timestampdiff(day,"2020-03-23",@date_close_more_than_precovid_maruti) as
number_of_dayes_required_by_maruti;


/*--BHARAT ART__*/

set @date_close_more_than_precovid_bhartiartl:=(select new_date from(select new_date,close,row_number() over(order by new_date asc)
as rank_based_on_new_date from bhartiartl where new_date between "2020-03-23" and "2021-04-30" and close>= @pre_covid_price_bhartiartl)
as A3 where rank_based_on_new_date =1);
select @date_close_more_than_precovid_bhartiartl;
select timestampdiff(day,"2020-03-23",@date_close_more_than_precovid_bhartiartl) as
number_of_dayes_required_by_bhartiartl;



/*--ultracemco__*/

set @date_close_more_than_precovid_ultracemco:=(select new_date from(select new_date,close,row_number() over(order by new_date asc)
as rank_based_on_new_date from ultracemco where new_date between "2020-03-23" and "2021-04-30" and close>= @pre_covid_price_ultracemco)
as A3 where rank_based_on_new_date =1);
select @date_close_more_than_precovid_ultracemco;
select timestampdiff(day,"2020-03-23",@date_close_more_than_precovid_ultracemco) as
number_of_dayes_required_by_ultracemco;
/*
ultratech cement  205
Bharti Artel fall 44
maruti suzuki fall 147*/

create table recovary_days
(symbol varchar(100),percentage_fall int);
insert into recovary_days
(symbol,percentage_fall )
values("MARUTI",147),("BHARATIART",44),("ULTRACEMCO",205);

select *,dense_rank() over(order by percentage_fall asc)as ranking from recovary_days;
alter table recovary_days
rename column percentage_fall to recovary_time;

select *,dense_rank() over(order by recovary_time asc)as ranking from recovary_days;

/*----Q4)NUMBER OF DAYS STOCK PRICE CLOSED ABOVE ITS PREVIOUS DAY CLOSING PRICE*/
drop view A4;
create view A4 as (select symbol,new_date,close from bhartiartl

union
select symbol,new_date,close from maruti

union

select symbol,new_date,close from ultracemco);

select * from A4;

select symbol,sum(if((close>prev_day_cc),1,0))as number_days_close_above_prev_close,dense_rank() 
over(order by sum(if((close>prev_day_cc),1,0))desc)as `rank` from
(select symbol,new_date,close,lag(close) over(partition by symbol order by new_date
asc)as prev_day_cc from A4)as XYZ group by symbol;



/*Q5) FIND CAGR*/
/* MARUTI*/
set @begin_price_maruti :=(select close from maruti where new_date="2010-01-04");
set @end_price_maruti :=(select close from maruti where new_date="2021-04-30");

select @begin_price_maruti ;

select @end_price_maruti ;

set @number_of_years:=(select round(timestampdiff(day,"2010-01-04","2021-04-30")/365,3));

select round((power((@end_price_maruti/@begin_price_maruti),
(1/@number_of_years))-1)*100,4)
 as Maruti_CAGR;
 
 
 /* bhartiartl*/
set @begin_price_bhartiartl:=(select close from bhartiartl where new_date="2010-01-04");
set @end_price_bhartiartl :=(select close from bhartiartl where new_date="2021-04-30");

select @begin_price_bhartiartl;

select @end_price_bhartiartl;



select round((power((@end_price_bhartiartl/@begin_price_bhartiartl),
(1/@number_of_years))-1)*100,4)
 as bhartiartl_CAGR;
 
 
 /* ultracemco*/
set @begin_price_ultracemco:=(select close from ultracemco where new_date="2010-01-04");
set @end_price_ultracemco:=(select close from ultracemco where new_date="2021-04-30");

select @begin_price_ultracemco;

select @end_price_ultracemco;



select round((power((@end_price_ultracemco/@begin_price_ultracemco),
(1/@number_of_years))-1)*100,4)
 as ultracemco_CAGR;
 
 
 
 /*
ultratech cement CAGR 17.9695
Bharti Artel CAGR 4.52
maruti suzuki CAGR 13.41*/

create table CAGR_table
(symbol varchar(100),CAGR double);
insert into CAGR_table
(symbol,CAGR  )
values("MARUTI",13.41),("BHARATIART",4.52),("ULTRACEMCO",17.9695);

select *,dense_rank() over(order by CAGR DESC)as ranking from CAGR_table;


/*Q6) Find month with highest volume*/

/*BHARTI AIRTEL*/
 set @max_vol_bhartiartl:=(select max(volume) as Maximum_Volume from bhartiartl);
 
 select symbol,month(new_date) as month,year(new_date)as year,volume as max_volume
from bhartiartl where volume=@max_vol_bhartiartl;



/*maruti*/
 set @max_vol_maruti:=(select max(volume) as Maximum_Volume from maruti);
 
 select symbol,month(new_date) as month,year(new_date)as year,volume as max_volume
from maruti where volume=@max_vol_maruti;


/*maruti*/
 set @max_vol_ultracemco:=(select max(volume) as Maximum_Volume from ultracemco);
 
 select symbol,month(new_date) as month,year(new_date)as year,volume as max_volume
from ultracemco where volume=@max_vol_ultracemco;
